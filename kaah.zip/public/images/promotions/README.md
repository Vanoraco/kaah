# Promotion Images

This directory contains images for the promotion cards on the homepage.

- `promo-vegetables.jpg` - Image for the "Sale of the Month" promotion
- `promo-meat.jpg` - Image for the "Low-Fat Meat" promotion
- `promo-fruits.jpg` - Image for the "100% Fresh Fruit" promotion

These images should be replaced with actual product images from your store.
